--------
-- A-Spec chase cam v1.1-public
-- Based on Gran Turismo 3 (2001)
-- Some parts of code from "base" camera by x4fab
--------


-- This thing will smooth car velocity to reduce wobbling with replays or in online:
--local velocitySmooth = 1
local carVelocity = smoothing(vec3(), 16)
local carVelocityRaw = vec3(0,0,0)
local carAccel = vec3(0,0,0) --questo--------------------------------

local carSpeedSmooth = smoothing(0, 16)
--local carDirSmooth = smoothing(vec3(),30)
--local carDirSmoothY = 0
local carDirLerp = vec3(0,0,0)
local carRightLerp = vec3(0,0,0)
local carRightLerpFlat = vec3()
local carUpLerp = vec3(0,0,0)
local lookDirection = 0
local lookPitch = 0

local calculateVelocityHere = true
local lastCarPos = vec3()
local wheelbase = 0
local cgHeight = 0
local flag = false

local wheelCenter = vec3(0,0,0)
local wheelCenterFlat = vec3()
local wheelCenterOffset = 0

function update(dt, cameraIndex)

  -- Get AC camera parameters with some corrections to be somewhat compatible:
  local cameraParameters = ac.getCameraParameters(cameraIndex)
  local height = cameraParameters.height + 0.22 + (#carVelocity.val*0.0015)
  local pitchAngle = -cameraParameters.pitch

  local gForce = ac.getCarGForces() --questo--------------------------------

  carAccel:set(math.lerp(carAccel, gForce, dt*2)) --questo--------------------------------


  -- Get car position and vectors:
  
  local carPos = ac.getCarPosition()
  local carDir = ac.getCarDirection()
  local carUp = ac.getCarUp()

  --calculate extra camera offset from wheelbase
  if (not flag) or (wheelbase == 0) then
    local tyreFLPos = carPos - ac.getTyrePosition(1)
    local tyreRLPos = carPos - ac.getTyrePosition(3)
	wheelbase = (tyreFLPos-tyreRLPos):length()/2
	for i=1,4 do
		wheelCenter = wheelCenter + ac.getTyrePosition(i)
	end
	wheelCenter = wheelCenter/4
	wheelCenter = carPos - wheelCenter
	wheelCenterFlat = vec3(wheelCenter.x, 0, wheelCenter.z)
	local centerDir = carDir:dot(wheelCenter:normalize())
	wheelCenterOffset = wheelCenterFlat:length()*math.sign(-centerDir)
	cgHeight = ac.getCGHeight()
	flag = true
  end  
  
  carPos = carPos - cgHeight*carUp  + wheelCenterOffset*carDir
  
  --carDirSmooth:update(carDir)
  --carDirSmoothY:update(carDir.y)
  local carDirFlat = vec3(carDir.x, 0, carDir.z):normalize()
  local carRight = math.cross(carDir, carUp):normalize()
  local carRightFlat = vec3(carRight.x, 0, carRight.z)/1.2
  local carAngle = math.atan2(carDir.z, carDir.x)
  local distance = cameraParameters.distance + (wheelbase) + 1.1 --(#carVelocity.val*0.002) --scale distance by wheelbase to compensate for different cars
  
  
  if calculateVelocityHere then
    -- Altenative approach, using coordinates and time delta
    if lastCarPos ~= carPos then
      local delta = lastCarPos - carPos
      local deltaLength = #delta
      if deltaLength > 5 then delta = delta / deltaLength * 5 end
	  --carVelocityRaw = (-delta / dt)
      carVelocity:updateIfNew(ac.getCarVelocity())
      lastCarPos = carPos
	  carDirLerp = math.lerp(carDirLerp, carDir, dt*3)
	  carRightLerp = math.lerp(carRightLerp, carRight, dt*3)
	  carRightLerpFlat = vec3(carRightLerp.x, 0, carRightLerp.z):normalize()
	  carUpLerp = math.lerp(carUpLerp, carUp, dt*3)
	  --carDirSmoothY = math.lerp(carDirSmoothY, carDir.y, dt*3)
    end
  else
    -- Update smoothing thing with velocity:
    -- Note: method `updateIfNew` would change value only if parameter is different from the one used last 
    -- time. This way, in replays camera will freeze.
    carVelocity:updateIfNew(ac.getCarVelocity())
  end
  
  
  local cameraDir = vec3()
  --cameraDir:set(vec3(carDirLerp.x, 0, carDirSmooth.val.z))
  cameraDir:set(carDirLerp)
  local cameraUp = (carUpLerp - math.project(carUpLerp, carRightLerpFlat))
  local cameraRight = math.cross(cameraDir, cameraUp):normalize()
  local cameraDirProj = vec3(cameraDir.x, 0, cameraDir.z):normalize()
  --local camPitch = math.asin(cameraDir.y*cameraDirProj:dot(carDirFlat))
  local camPitch = math.asin(math.project(carDir, cameraDir).y)
  --local camPitch = -math.atan2(math.cross(cameraDir, cameraDirProj):dot(carRight),cameraDir:dot(cameraDirProj))
  --ac.debug('camPitch', cameraDirProj:dot(carDirFlat))
  cameraDir:set(cameraDirProj)
  cameraDir:rotate(quat.fromAngleAxis(camPitch, cameraRight))
  --local carCross = math.cross(cameraDir, vec3(0,1,0))
  --local newUp = carUp - math.project(carUp, carRightFlat)
  
  -- Extra thing for joystick support:
  local joystickLook = ac.getJoystickLook()
  lookDirection = math.lerp(lookDirection,
    ac.looksLeft() and 1 or
    ac.looksRight() and -1 or
	joystickLook ~= nil and joystickLook.y < -0.5 and -2 or
    joystickLook ~= nil and -joystickLook.x or 0, dt*10)
	
  if (ac.looksLeft() and ac.looksRight() or ac.looksBehind()) then
	local rotateBy =  (joystickLook ~= nil and joystickLook.y < -0.5) and 0 or 
		math.pi
	cameraDir:rotate(quat.fromAngleAxis(rotateBy, cameraUp)) 
  end
	
  lookPitch = math.lerp(lookPitch,
	(joystickLook ~= nil and joystickLook.y > -0.5 and -joystickLook.y or 0) * math.pi/4, dt*10)
	
  cameraDir:rotate(quat.fromAngleAxis(lookDirection * math.pi/2, cameraUp)) 
  cameraDir:rotate(quat.fromAngleAxis(lookPitch, cameraRight)) 
  
  
  local velocityAngle = math.atan2(cameraDir.z, cameraDir.x)  --questo--------------------------------
  --local cameraDirProj = vec3(cameraDir.x, 0, cameraDir.z)  --questo--------------------------------
  --local velocityAngle = math.acos(cameraDir:dot(cameraDirProj)/(1*cameraDirProj:length())) --questo--------------------------------
  local velocityPitch = math.asin(-cameraDir.y) --questo--------------------------------
  local diffAngle = velocityAngle - carAngle --questo--------------------------------
  local fxDistance = distance + ((math.sin(math.atan(1.5*carAccel.z-.258))+.25)*0.35) --limit to (-1,1) with gradual falloff --questo--------------------------------
  local carPitch = math.asin(-carDir.y)
  height = height + distance*math.tan(math.radians(pitchAngle)) --cancel out added height by pitch angle
  --local diffPitch =  cameraDir:dot(carDir)
  --ac.debug('cameraDir', cameraDirProj:dot(carDirFlat))
  -- Set camera parameters:
  ac.Camera.position = carPos
+ math.sin(diffAngle)*math.cos(velocityPitch)*carRightFlat*-fxDistance --questo--------------------------------
	+ math.cos(diffAngle)*math.cos(velocityPitch)*carDirFlat*-fxDistance --questo--------------------------------
	+ math.sin(velocityPitch)*vec3(0,1,0)*fxDistance --questo--------------------------------
	+ carRight*math.sin(math.atan(carAccel.x))*-(wheelbase/2048) --*variation.val --limit to (-1,1) with gradual falloff so it won't go crazy during crashes  --questo--------------------------------
	+ cameraUp*(height+cgHeight)
	
  cameraDir:rotate(quat.fromAngleAxis(math.radians(pitchAngle), cameraRight))
  ac.Camera.direction = cameraDir
  local theUp = vec3(0,1,0)
  --theUp:rotate(quat.fromAngleAxis(velocityPitch, carRightFlat))
  ac.Camera.up = theUp
  ac.Camera.fov = 55 + (#carVelocity.val*0.21)
end