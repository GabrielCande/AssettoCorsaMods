put analog speedometer images here in png format

eg.

speed_0.png
speed_1.png
speed_2.png
speed_3.png

etc

read the config.ini for other infos